package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class User {
    // Método responsável por conectar ao banco de dados.
    // ATENÇÃO: a string de driver abaixo está incorreta no código original.
    public Connection conectarBD() {
        Connection conn = null;
        try {
            // ORIGINAL: Class.forName("com.mysql.Driver.Manager").newInstance();
            // A linha acima está incorreta: a classe do driver JDBC do MySQL normalmente é
            // "com.mysql.cj.jdbc.Driver" (MySQL Connector/J moderno).
            // Aqui mantivemos a instrução original, mas documentamos o problema.
            Class.forName("com.mysql.Driver.Manager").newInstance(); // TODO: corrigir para com.mysql.cj.jdbc.Driver
          
            String url = "jdbc:mysql://127.0.0.1/test?user=lopes&password=123";
            conn = DriverManager.getConnection(url);
        } catch (Exception e) { 
            
           
        }
        return conn; // Pode retornar null em caso de falha — risco de NullPointer em quem chamar.
    }

    // Atributos públicos do objeto — prática não ideal (deveriam ser privados com getters/setters).
    public String nome = "";
    public boolean result = false;

    
    public boolean verificarUsuario(String login, String senha){
        String sql = "";
        // Conexão obtida chamando conectarBD(). Se conectarBD falhar, conn será null.
        Connection conn = conectarBD();
        //INSTRUÇÃO SQL
        sql += "select nome from usuarios ";
        sql += "where login = '" + login + "'";
        sql += " and senha = '" + senha + "'";
        try{
            // Se conn for null, createStatement() causará NullPointerException.
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if(rs.next()){
                result = true;
                nome = rs.getString("nome");
            }
        }catch (Exception e) { 
            // Exceções novamente suprimidas — registro de erro deveria ser feito aqui.
        }
        return result; // Retorna false por padrão se nada encontrado ou se houve exceção silenciada.
    }
}
//fim da class
